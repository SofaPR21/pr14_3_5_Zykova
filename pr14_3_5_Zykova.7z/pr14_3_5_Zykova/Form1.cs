﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace pr14_3_5_Zykova
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //получаем n из NumericUpDown
            int n = (int)numericUpDown1.Value;
            Queue<int> numbers = new Queue<int>();

            //заполняем очередь числами от 1 до n
            for (int i = 1; i <= n; i++)
            {
                numbers.Enqueue(i);
            }

            //очищаем ListBox перед выводом
            listBox1.Items.Clear();

            listBox1.Items.Add("n = " + numbers.Count);
            listBox1.Items.Add("Размерность очереди = " + numbers.Count);
            listBox1.Items.Add("Верхний элемент очереди = " + numbers.Count);

            string str = "";

            //элементы из очереди добавляем в ListBox
            while (numbers.Count > 0)
            {
                str += numbers.Dequeue() + " ";
            }

            listBox1.Items.Add("Содержимое очереди = " + str.Trim());

            numbers.Clear();

            listBox1.Items.Add("Новая резмерность очереди = " + numbers.Count);

           
        }

       
        private void button2_Click(object sender, EventArgs e)
        {
            Queue<string> person = new Queue<string>();
            string file = "file.txt";

            if (File.Exists(file))
            {
                try
                {
                    using (StreamReader write = new StreamReader(file))
                    {
                        string line;

                        while ((line = write.ReadLine()) != null)
                        {
                            person.Enqueue(line);
                        }

                        foreach (string pers in person)
                        {
                            string[] warp = pers.Split(' ');
                            int age = Convert.ToInt32(warp[4]);

                            if (age < 40)
                            {

                            }
                        }
                        

                        while (person.Count > 0)
                        {
                            listBox2.Items.Add(person.Dequeue());
                        }
                    }

                    MessageBox.Show("файл успешко создан и заполнен!");

                }

                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }
            else
            {
                MessageBox.Show("такого файла не существует.");
            }
        
        }
    }
}
