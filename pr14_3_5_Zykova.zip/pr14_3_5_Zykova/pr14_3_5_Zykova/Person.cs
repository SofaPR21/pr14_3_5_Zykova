﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr14_3_5_Zykova
{
    class Person
    {
        private string _surname;
        private string _name;
        private string _thirdname;
        private int _age;
        private double _weight;

        public Person() { }

        public Person(string fam, string name, string ot, int age, double weith)
        {
            this._surname = fam;
            this._name = name;
            this._thirdname = ot;
            this._age = age;
            this._weight = weith;
        }

        public string SurnameValue
        {
            get { return _surname; }
            set { _surname = value; }
        }

        public string NameValue
        {
            get { return _name; }
            set { _name = value; }
        }

        public string ThirdnameValue
        {
            get { return _thirdname; }
            set { _thirdname = value; }
        }

        public int AgeValue
        {
            get { return _age; }
            set { _age = value; }
        }

        public double WeightValue
        {
            get { return _weight; }
            set { _weight = value; }
        }

        public override string ToString()
        {
            return $"{SurnameValue} {NameValue} {ThirdnameValue} - возраст: {AgeValue}, вес: {WeightValue}";
        }
    }
}
